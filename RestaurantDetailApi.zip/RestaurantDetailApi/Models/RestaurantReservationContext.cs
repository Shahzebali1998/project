﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.SqlServer;
using Microsoft.EntityFrameworkCore;

namespace RestaurantDetailApi.Models
{
  
        public class RestaurantReservationContext : DbContext
        {
            public DbSet<RestaurantDetail> RestaurantDetails { get; set; }


            public RestaurantReservationContext(DbContextOptions<RestaurantReservationContext> options) : base(options)
            {
            }
            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.Entity<RestaurantDetail>().ToTable("ResturantDetail");
            }
        }
    
}
