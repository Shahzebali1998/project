﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantDetailApi.Models;

namespace RestaurantDetailApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantDetailsController : ControllerBase
    {
        private readonly RestaurantReservationContext _context;

        public RestaurantDetailsController(RestaurantReservationContext context)
        {
            _context = context;
        }

        // GET: api/RestaurantDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RestaurantDetail>>> GetRestaurantDetails()
        {
            return await _context.RestaurantDetails.ToListAsync();
        }

        // GET: api/RestaurantDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RestaurantDetail>> GetRestaurantDetail(long id)
        {
            var restaurantDetail = await _context.RestaurantDetails.FindAsync(id);

            if (restaurantDetail == null)
            {
                return NotFound();
            }

            return restaurantDetail;
        }

        // PUT: api/RestaurantDetails/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRestaurantDetail(long id, RestaurantDetail restaurantDetail)
        {
            if (id != restaurantDetail.RestaurantId)
            {
                return BadRequest();
            }

            _context.Entry(restaurantDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RestaurantDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RestaurantDetails
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<RestaurantDetail>> PostRestaurantDetail(RestaurantDetail restaurantDetail)
        {
            _context.RestaurantDetails.Add(restaurantDetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRestaurantDetail", new { id = restaurantDetail.RestaurantId }, restaurantDetail);
        }

        // DELETE: api/RestaurantDetails/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRestaurantDetail(long id)
        {
            var restaurantDetail = await _context.RestaurantDetails.FindAsync(id);
            if (restaurantDetail == null)
            {
                return NotFound();
            }

            _context.RestaurantDetails.Remove(restaurantDetail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RestaurantDetailExists(long id)
        {
            return _context.RestaurantDetails.Any(e => e.RestaurantId == id);
        }
    }
}
